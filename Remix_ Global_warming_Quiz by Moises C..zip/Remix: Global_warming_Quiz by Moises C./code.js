var cards = ["1st_card", "2nd_card", "3rd_card", "4th_card", "5th_card"];
var index;
var totalQ = 4;
var wrong = 0;
var correct = 0;
setScreen("home");
function randomQ() {
  console.log("CARDS= " + cards);
  if (totalQ < 0) {
    setScreen("results");
  } else {
    console.log("INDEX= " + index);
    setScreen(cards[index]);
    removeItem(cards, index);
    totalQ = totalQ - 1;
    console.log("totalQ= " + totalQ);
    return totalQ;
  }
}
onEvent("home_start_btn", "click", function( ) {
  console.log("home start btn was clicked");
  index = randomNumber(0, totalQ);
  console.log("index= " + index);
  totalQ = randomQ(totalQ);
});
onEvent("1st_card_btn1", "click", function( ) {
  console.log("1st btn on the 1st card was clicked");
  correct = correct + 1;
  setScreen("1st_correct_card");
});
onEvent("1st_card_btn2", "click", function( ) {
  console.log("2nd btn on the 1st card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("1st_card_btn3", "click", function( ) {
  console.log("3rd btn on the 1st card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("1st_card_btn4", "click", function( ) {
  console.log("4th btn on the 1st card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("2nd_card_btn2", "click", function( ) {
  console.log("2nd btn on the 2nd card was clicked");
  correct = correct + 1;
  setScreen("1st_correct_card");
});
onEvent("2nd_card_btn1", "click", function( ) {
  console.log("2nd btn on the 2nd card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("2nd_card_btn3", "click", function( ) {
  console.log("3rd btn on the 2nd card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("2nd_card_btn4", "click", function( ) {
  console.log("4th btn on the 2nd card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("3rd_card_btn3", "click", function( ) {
  console.log("3rd btn on the 3rd card was clicked");
  correct = correct + 1;
  setScreen("1st_correct_card");
});
onEvent("3rd_card_btn1", "click", function( ) {
  console.log("1st btn on the 3rd card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("3rd_card_btn2", "click", function( ) {
  console.log("2nd btn on the 3rd card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("3rd_card_btn4", "click", function( ) {
  console.log("4th btn on the 3rd card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("4th_card_btn4", "click", function( ) {
  console.log("4th btn on the 4th card was clicked");
  correct = correct + 1;
  setScreen("1st_correct_card");
});
onEvent("4th_card_btn1", "click", function( ) {
  console.log("1st btn on the 4th card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("4th_card_btn2", "click", function( ) {
  console.log("2nd btn on the 4th card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("4th_card_btn3", "click", function( ) {
  console.log("3rd btn on the 4th card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("5th_card_btn4", "click", function( ) {
  console.log("4th btn on the 5th card was clicked");
  correct = correct + 1;
  setScreen("1st_correct_card");
});
onEvent("5th_card_btn1", "click", function( ) {
  console.log("1st btn on the 5th card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("5th_card_btn2", "click", function( ) {
  console.log("2nd btn on the 5th card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("5th_card_btn3", "click", function( ) {
  console.log("3rd btn on the 5th card was clicked");
  wrong = wrong + 1;
  setScreen("1st_wrong_card");
});
onEvent("1st_correct_next_q_btn", "click", function( ) {
  console.log("1st next Q btn on the 1st correct screen was clicked");
  index = randomNumber(0, totalQ);
  totalQ = randomQ(totalQ);
});
onEvent("1st_wrong_next_q_btn", "click", function( ) {
  console.log("1st next Q btn on the 1st wrong screen was clicked");
  index = randomNumber(0, totalQ);
  totalQ = randomQ(totalQ);
});
onEvent("2nd_correct_next_q_btn", "click", function( ) {
  console.log("2nd next Q btn on the 2nd correct screen was clicked");
  setScreen("3rd_card");
});
onEvent("2nd_wrong_next_q_btn", "click", function( ) {
  console.log("2nd next Q btn on the 2nd wrong screen was clicked");
  setScreen("3rd_card");
});
onEvent("3rd_correct_next_q_btn", "click", function( ) {
  console.log("3rd next Q btn on the 3rd correct screen was clicked");
  setScreen("4th_card");
});
onEvent("3rd_wrong_next_q_btn", "click", function( ) {
  console.log("3rd next Q btn on the 3rd wrong screen was clicked");
  setScreen("4th_card");
});
onEvent("4th_correct_next_q_btn", "click", function( ) {
  console.log("4th next Q btn on the 4th correct screen was clicked");
  setScreen("5th_card");
});
onEvent("4th_wrong_next_q_btn", "click", function( ) {
  console.log("4th next Q btn on the 4th wrong screen was clicked");
  setScreen("5th_card");
});
onEvent("5th_correct_next_q_btn", "click", function( ) {
  console.log("5th next Q btn on the 5th correct screen was clicked");
  setScreen("results");
});
onEvent("5th_wrong_next_q_btn", "click", function( ) {
  console.log("5th next Q btn on the 5th wrong screen was clicked");
  setScreen("results");
});
onEvent("results_show_btn", "click", function( ) {
  console.log("show results btn on the results screen was clicked");
  setText("results_text_input", "correct: " + (correct + (" incorrect: " + wrong)));
});
onEvent("credits_home_btn", "click", function( ) {
  console.log("back home btn on the credits screen was clicked");
  wrong = 0;
  correct = 0;
  totalQ = 4;
  appendItem(cards, "1st_card");
  appendItem(cards, "2nd_card");
  appendItem(cards, "3rd_card");
  appendItem(cards, "4th_card");
  appendItem(cards, "5th_card");
  console.log("totalQ " + totalQ);
  console.log("index" + index);
  console.log("cards" + cards);
  setText("results_text_input", " ");
  setScreen("home");
});
onEvent("credits_btn", "click", function( ) {
  console.log("credits btn on the results screen was clicked");
  setScreen("credits_card");
});
onEvent("epa_label", "click", function( ) {
  open("https://www.epa.gov/");
});
onEvent("un_label", "click", function( ) {
  open("https://www.un.org/en/");
});
